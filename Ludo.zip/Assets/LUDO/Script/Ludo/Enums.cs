public enum GameType
{
	Local,
	WithBot
}

//public enum GameMode
//{
//	Classic
//}

public enum PlayerCount
{	
	Two=2,
	Three=3,
	Four=4
}

public enum PlayerColor
{
	Red,
	Blue,
	Green,
	Yellow
}

public enum GameTheme
{
	Bright,
	Dark
}
