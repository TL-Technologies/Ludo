using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenericGameModeToggle : MonoBehaviour
{
	public GameType gameType;
}
