using UnityEngine;

public class GenericPlayerColorToggle : MonoBehaviour
{
	public PlayerColor playerColor;
}
