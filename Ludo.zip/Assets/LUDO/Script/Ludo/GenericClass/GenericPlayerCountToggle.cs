using UnityEngine;

public class GenericPlayerCountToggle : MonoBehaviour
{
	public PlayerCount playerCount;
}
